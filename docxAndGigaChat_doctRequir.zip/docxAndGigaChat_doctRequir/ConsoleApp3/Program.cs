﻿using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Drawing;
using Spire.Doc;
using Spire.Doc.Documents;
using Spire.Doc.Fields;

//здесь программа получает входной файл docx, и в выходной файл docx выгружает первое слово из текста и все таблицы и изображения

class Program
{
    static void Main(string[] args)
    {
        string inputPath = @"C:\Users\admin\Downloads\5к демо ВПР м.docx";
        string outputPath = @"C:\Users\admin\Downloads\CreateWordDocument.docx";

        if (!File.Exists(inputPath))
        {
            Console.WriteLine("Входной файл не найден: " + inputPath);
            return;
        }

        try
        {
            using (Document src = new Document())
            using (Document dst = new Document())
            {
                src.LoadFromFile(inputPath);

                // Создадим одну секцию в выходном документе
                Section dstSection = dst.AddSection();

                bool firstWordCaptured = false;
                string firstWord = null;

                foreach (Section srcSection in src.Sections)
                {
                    foreach (DocumentObject obj in srcSection.Body.ChildObjects)
                    {
                        if (obj is Table srcTable)
                        {
                            // Копируем таблицу
                            Table dstTable = CopyTable(srcTable, dst);

                            // Устанавливаем границы для всей таблицы (чёрные, сплошные, толщ. 1f)
                            try
                            {
                                // Обработать границы таблицы (в целом)
                                dstTable.TableFormat.Borders.BorderType = BorderStyle.Single;
                                dstTable.TableFormat.Borders.Color = Color.Black;
                                dstTable.TableFormat.Borders.LineWidth = 1f;
                            }
                            catch { /* игнорируем, если свойства недоступны */ }

                            // Также для надёжности задаём границы для каждой ячейки
                            foreach (TableRow row in dstTable.Rows)
                            {
                                foreach (TableCell cell in row.Cells)
                                {
                                    try
                                    {
                                        cell.CellFormat.Borders.BorderType = BorderStyle.Single;
                                        cell.CellFormat.Borders.Color = Color.Black;
                                        cell.CellFormat.Borders.LineWidth = 1f;
                                    }
                                    catch { }
                                }
                            }

                            // Добавляем таблицу в документ
                            dstSection.Body.ChildObjects.Add(dstTable);

                            // Добавляем пустой абзац (разрыв между таблицами)
                            Paragraph spacer = dstSection.AddParagraph();
                            // Можно добавить пустую строку без текста — оставим просто пустой параграф.
                        }
                        else if (obj is Paragraph srcPara)
                        {
                            Paragraph newPara = dstSection.AddParagraph();

                            foreach (DocumentObject child in srcPara.ChildObjects)
                            {

                                if (child is TextRange tr)
                                {
                                    if (!firstWordCaptured)
                                    {
                                        string word = ExtractFirstWord(tr.Text);
                                        if (!string.IsNullOrEmpty(word))
                                        {
                                            TextRange newTr = newPara.AppendText(word);
                                            CopyCharacterFormat(tr, newTr);
                                            firstWordCaptured = true;
                                            firstWord = word;
                                        }
                                    }
                                }
                                else if (child is DocPicture pic)
                                {
                                    Image img = pic.Image;
                                    if (img != null)
                                    {
                                        DocPicture newPic = newPara.AppendPicture(img);
                                        try
                                        {
                                            newPic.Width = pic.Width;
                                            newPic.Height = pic.Height;
                                        }
                                        catch { }
                                    }
                                }
                                else
                                {
                                    // прочие типы — пропускаем (или расширим по требованию)
                                }
                            }

                            if (newPara.ChildObjects.Count == 0)
                            {
                                dstSection.Body.ChildObjects.Remove(newPara);
                            }
                        }
                        else
                        {
                            // прочие верхнеуровневые объекты — можно обработать при необходимости
                        }
                    }
                }

                dst.SaveToFile(outputPath, FileFormat.Docx);
                Console.WriteLine("Готово. Первый найденный слово: " + (firstWord ?? "<не найдено>"));
                Console.WriteLine("Сохранено: " + outputPath);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Ошибка: " + ex.Message);
        }
    }

    static Table CopyTable(Table srcTable, Document dstDoc)
    {
        int rows = srcTable.Rows.Count;
        int maxCols = 0;
        foreach (TableRow r in srcTable.Rows)
            if (r.Cells.Count > maxCols) maxCols = r.Cells.Count;

        Table dstTable = new Table(dstDoc);
        dstTable.ResetCells(rows, maxCols);

        for (int r = 0; r < rows; r++)
        {
            TableRow srcRow = srcTable.Rows[r];
            TableRow dstRow = dstTable.Rows[r];

            for (int c = 0; c < maxCols; c++)
            {
                TableCell dstCell = dstRow.Cells[c];

                if (c < srcRow.Cells.Count)
                {
                    TableCell srcCell = srcRow.Cells[c];

                    try
                    {
                        dstCell.CellFormat.VerticalAlignment = srcCell.CellFormat.VerticalAlignment;
                    }
                    catch { }

                    foreach (Paragraph srcPara in srcCell.Paragraphs)
                    {
                        Paragraph dstPara = dstCell.AddParagraph();

                        foreach (DocumentObject child in srcPara.ChildObjects)
                        {
                            if (child is TextRange tr)
                            {
                                TextRange newTr = dstPara.AppendText(tr.Text);
                                CopyCharacterFormat(tr, newTr);
                            }
                            else if (child is DocPicture pic)
                            {
                                Image img = pic.Image;
                                if (img != null)
                                {
                                    DocPicture newPic = dstPara.AppendPicture(img);
                                    try
                                    {
                                        newPic.Width = pic.Width;
                                        newPic.Height = pic.Height;
                                    }
                                    catch { }
                                }
                            }
                            else
                            {
                                // дополнительные типы при необходимости
                            }
                        }
                    }
                }
            }
        }

        return dstTable;
    }

    static void CopyCharacterFormat(TextRange src, TextRange dst)
    {
        try
        {
            dst.CharacterFormat.Bold = src.CharacterFormat.Bold;
            dst.CharacterFormat.Italic = src.CharacterFormat.Italic;
            dst.CharacterFormat.FontName = src.CharacterFormat.FontName;
            dst.CharacterFormat.FontSize = src.CharacterFormat.FontSize;
            dst.CharacterFormat.TextColor = src.CharacterFormat.TextColor;
            dst.CharacterFormat.UnderlineStyle = src.CharacterFormat.UnderlineStyle;
        }
        catch { }
    }

    static string ExtractFirstWord(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return null;

        var m = Regex.Match(text, @"\w+", RegexOptions.Singleline);
        return m.Success ? m.Value : null;
    }
}

