﻿using System.Text.Json;
using System.Text.Json.Serialization;
using System.IO;

namespace ConsoleApp4
{
    //требования к системе, которые есть в журнале СГУГиТ "Вестник"
    // ------ DTO-классы требований ------
    public class RequirementsDto
    {
        public PageSetupDto PageSetup { get; set; } = new();
        public TextRulesDto Text { get; set; } = new();
        public TablesRulesDto Tables { get; set; } = new();
        public FiguresRulesDto Figures { get; set; } = new();
        public LimitsDto Limits { get; set; } = new();
        public CopyrightDto Copyright { get; set; } = new();
        public OutputRulesDto Output { get; set; } = new();
    }

    public class PageSetupDto   //настройки для страниц
    {
        public string PaperSize { get; set; } = "A4";  //размер бумаги
        public string Orientation { get; set; } = "Portrait";  //ориентация
        public MarginsCm MarginsCm { get; set; } = new(); // поля
        public double FooterDistanceCm { get; set; } = 2.0; //расстояние до колонтикула
    }
    public class MarginsCm //поля страниц документа
    {
        public double Top { get; set; } = 2.0;  //верхнее поле
        public double Left { get; set; } = 2.0; //левое поле
        public double Right { get; set; } = 2.0; //правое поле
        public double Bottom { get; set; } = 2.7;  //нижнее поле
    }

    public class TextRulesDto
    {
        public TextStyleDto Main { get; set; } = new()  //требования к основному тексту
        {
            Font = "Times New Roman",  //шрифт основного текста
            SizePt = 14, //кегель основного текста
            LineSpacing = 1.5, //междустрочный интервал (полуторный)
            FirstLineIndentCm = 0.6, //абзацный отступ
            Alignment = "Justify" //Выравнивание текста по ширине
        };
        public TextStyleDto Title { get; set; } = new() //требования к названию статьи
        {
            Font = "Arial",  //шрифт названия
            SizePt = 12, //кегель названия
            Bold = true, //полужирный
            Alignment = "Center",  //выравнивание по центру
            MaxWords = 12 //максимальное количество слов в названии
        };
        public TextStyleDto Authors { get; set; } = new() //требования к строчке с авторами
        {
            Font = "Times New Roman", //шрифт авторов
            SizePt = 12, //кегель авторов
            Italic = true, //курсив
            Alignment = "Center",  //выравнивание по центру
            MaxItems = 4 //максимально авторов
        };
        public TextStyleDto AnnexAndBiblio { get; set; } = new() //требования к аннотации и библиографии
        {
            Font = "Times New Roman", //шрифт библиографии
            SizePt = 12, //кегель библиографии
            LineSpacing = 1.5 //междустрочный интервал (полуторный)
        };
        public TextStyleDto Udk { get; set; } = new() // требование к УДК 
        {
            Font = "Times New Roman", // шрифт УДК
            SizePt = 12, // кегель УДК
            Alignment = "Left"  // выравнивание УДК по левому краю
        };
    }

    public class TextStyleDto // класс, описывающий стиль текста/абзаца
    {
        public string Font { get; set; } // название шрифта (напр., "Times New Roman")
        public double? SizePt { get; set; } // размер шрифта в пунктах (nullable)
        public double? LineSpacing { get; set; } // межстрочный интервал (например 1.0, 1.5) (nullable)
        public double? FirstLineIndentCm { get; set; } // абзацный отступ первой строки в сантиметрах (nullable)
        public string Alignment { get; set; } // выравнивание: "Left","Center","Right","Justify"
        public bool? Bold { get; set; } // полужирный стиль (nullable)
        public bool? Italic { get; set; } // курсив (nullable)
        public int? MaxWords { get; set; } // максимальное число слов (например для заголовка) (nullable)
        public int? MaxItems { get; set; } // максимальное число элементов (например число авторов) (nullable)
    }

    public class TablesRulesDto // класс, описывающий правила для таблиц
    {
        public int FontPt { get; set; } = 12; // стандартный размер шрифта в таблице (по умолчанию 12 pt)
        public double LineSpacing { get; set; } = 1.0; // межстрочный интервал в таблице (одинарный по умолчанию)
        public BorderSpec TableBorder { get; set; } = new() // спецификация границы таблицы, инициализируется по умолчанию
        {
            ColorHex = "#000000", // цвет границы таблицы в HEX
            WidthPt = 1.0, // толщина границы в пунктах
            Style = "Single" // стиль границы (одинарная сплошная линия)
        };
        public bool PreventShading { get; set; } = true; // блокировка фоновой заливки в таблицах (true = запрещать)
        public string Alignment { get; set; } = "Center"; // выравнивание всей таблицы по центру
        public string CaptionFormat { get; set; } = "Таблица {n}) - {title}"; // формат подписи таблицы (номер и название)
        public string CaptionAlignment { get; set; } = "Right"; // выравнивание подписи таблицы (по правому краю)
        public string TitleAlignmentOverTable { get; set; } = "Center"; // выравнивание названия над таблицей по центру
    }

    public class BorderSpec // класс, описывающий параметры рамки/границы
    {
        public string ColorHex { get; set; } = "#000000"; // цвет границы в HEX по умолчанию
        public double WidthPt { get; set; } = 1.0; // толщина границы в пунктах по умолчанию
        public string Style { get; set; } = "Single"; // стиль границы по умолчанию ("Single" = одна сплошная)
    }

    public class FiguresRulesDto // класс правил для рисунков/подписей к рисункам
    {
        public string CaptionFormat { get; set; } = "Рис. {n}. {title}"; // формат подписи к рисунку (номер и название)
        public int CaptionFontPt { get; set; } = 12; // размер шрифта в подписи к рисунку в пунктах
        public string Alignment { get; set; } = "Center"; // выравнивание рисунка по центру
    }

    public class LimitsDto // класс, описывающий контроль объёмов и лимитов
    {
        public Range Pages { get; set; } = new() // диапазон допустимого числа страниц
        {
            Min = 12, // минимальное число страниц
            Max = 16 // максимальное число страниц

        };
        public int TitleWordsMax { get; set; } = 12; // максимальное число слов в названии
        public int AuthorsMax { get; set; } = 4; // максимальное число авторов
        public Range AbstractWords { get; set; } = new() // диапазон слов в аннотации
        {
            Min = 100, // минимум слов в аннотации
            Max = 250 // максимум слов в аннотации
        };

        public Range Keywords { get; set; } = new() // диапазон количества ключевых слов
        {
            Min = 7, // минимальное число ключевых слов
            Max = 12 // максимальное число ключевых слов
        };
    }

    public class Range // вспомогательный класс для диапазонов (min/max)
    {
        public int Min { get; set; } // минимальное значение диапазона
        public int Max { get; set; } // максимальное значение диапазона
    }

    public class CopyrightDto // класс, описывающий требования к знаку копирайта
    {
        public string Position { get; set; } = "end_after_authors_block"; // позиция блока копирайта (после блока авторов)
        public string Format { get; set; } = "© {authors}, {year}"; // формат записи копирайта
        public string AuthorNameFormat { get; set; } = "И. О. Фамилия"; // формат отображения ФИО авторов
        public bool MustMatchAuthorsInTitle { get; set; } = true; // требовать совпадение списка авторов с заголовком (true/false)
    }

    public class OutputRulesDto // класс правил для выходного формата/ответа
    {
        public bool StrictJsonOnly { get; set; } = true; // требовать от модели возвращать только JSON без доп. текста
        public string JsonRoot { get; set; } = "formattedDocument"; // корневой ключ ожидаемого JSON-ответа
    }
}
