﻿//
//есть файл с# с требованиями к системе. Нужно преобразовать docx в соответствии с этими требованиями

using System.Drawing;
using Spire.Doc;
using Spire.Doc.Documents;
using Spire.Doc.Fields;
using Document = Spire.Doc.Document;
using Section = Spire.Doc.Section;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputPath = args.Length > 0 ? args[0] : @"C:\Users\admin\Downloads\тезисы Великие имена истории России.docx"; ; // укажите путь к исходному файлу или передайте как аргумент
            if (!File.Exists(inputPath))
            {
                Console.WriteLine($"Input file not found: {inputPath}");
                return;
            }

            // целевой путь: Папка "Загрузки" пользователя
            string downloads = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            Directory.CreateDirectory(downloads);
            string outputPath = Path.Combine(downloads, "NewDocument.docx");

            // Создаём requirements (можно загрузить их из файла вместо жесткой инициализации)
            RequirementsDto req = new RequirementsDto();

            // Загружаем документ
            Document doc = new Document();
            doc.LoadFromFile(inputPath);

            // Применяем настройки
            ApplyPageSetup(doc, req.PageSetup);
            ProcessParagraphsAndTextFormatting(doc, req.Text);
            ProcessTables(doc, req.Tables);
            ProcessFigures(doc, req.Figures);
            EnsureBibliographyHeader(doc, req.Text); // минимальная корректировка библиографии
            EnsureCopyrightBlock(doc, req);

            // Сохраняем результат
            doc.SaveToFile(outputPath, FileFormat.Docx);
            Console.WriteLine($"Saved formatted document to: {outputPath}");
        }

        // ---------- Утилиты ----------
        static double CmToPoints(double cm) => cm * 72.0 / 2.54;

        // ---------- Page setup ----------
        static void ApplyPageSetup(Document doc, PageSetupDto page)
        {
            foreach (Section sec in doc.Sections)
            {
                // В Spire.Doc PaperSize может именоваться PaperSize.A4 или PageSize.A4; если потребуется, исправьте.
                sec.PageSetup.PageSize = PageSize.A4; // A4
                sec.PageSetup.Orientation = PageOrientation.Portrait; // книжная ориентация
                sec.PageSetup.Margins.Top = (float)CmToPoints(page.MarginsCm.Top);
                sec.PageSetup.Margins.Left = (float)CmToPoints(page.MarginsCm.Left);
                sec.PageSetup.Margins.Right = (float)CmToPoints(page.MarginsCm.Right);

                sec.PageSetup.Margins.Bottom = (float)CmToPoints(page.MarginsCm.Bottom);
                // расстояние до колонтитула:
                sec.PageSetup.FooterDistance = (float)CmToPoints(page.FooterDistanceCm);

                // Отключаем висячие строки (widow/orphan control) — если свойство есть:
                try
                {
                    foreach (Paragraph p in sec.Paragraphs)
                    {
                        // Если Available: p.Format.WidowControl = false; (в некоторых версиях API)
                        // Попробуем безопасно назначить, если свойство доступно:
                        var fmt = p.Format;
                        var prop = fmt.GetType().GetProperty("WidowControl");
                        if (prop != null && prop.CanWrite) prop.SetValue(fmt, false);
                    }
                }
                catch { /* игнорируем, если API не поддерживает */ }
            }
        }

        // ---------- Текст и параграфы ----------
        static void ProcessParagraphsAndTextFormatting(Document doc, TextRulesDto textReq)
        {
            // Проходим по всем параграфам и применяем общие правила.
            // Правила для спец. полей (УДК, Аннотация, Заголовок, Авторы) пытаемся найти по ключевым словам/позиции.
            bool firstParagraphProcessedAsTitle = false;
            int paragraphIndex = 0;

            foreach (Section sec in doc.Sections)
            {
                foreach (Paragraph p in sec.Paragraphs)
                {
                    paragraphIndex++;

                    string plain = p.Text?.Trim() ?? string.Empty;

                    // Простейшее определение заголовка: если это первый непустой параграф — делаем Title стиль
                    if (!firstParagraphProcessedAsTitle && !string.IsNullOrEmpty(plain))
                    {
                        ApplyTextStyleToParagraph(p, textReq.Title); // заголовок
                        firstParagraphProcessedAsTitle = true;
                        continue;
                    }

                    // УДК: если параграф начинается с "УДК" (без учёта регистра)
                    if (plain.StartsWith("УДК", StringComparison.OrdinalIgnoreCase) || plain.StartsWith("УДК:", StringComparison.OrdinalIgnoreCase))
                    {
                        ApplyTextStyleToParagraph(p, textReq.Udk);
                        p.Format.HorizontalAlignment = HorizontalAlignment.Left;
                        continue;
                    }

                    // Аннотация: параграф с заголовком "Аннотация" — следующий блок обрабатываем как аннотация
                    if (plain.Equals("Аннотация", StringComparison.OrdinalIgnoreCase) || plain.StartsWith("Аннотация:", StringComparison.OrdinalIgnoreCase))
                    {
                        // выставим сам заголовок по центру
                        p.Format.HorizontalAlignment = HorizontalAlignment.Center;
                        // следующий параграф(ы) — аннотация (если они есть)
                        var parentSec = sec;
                        int thisIndex = parentSec.Paragraphs.IndexOf(p);
                        if (thisIndex + 1 < parentSec.Paragraphs.Count)
                        {
                            Paragraph ann = parentSec.Paragraphs[thisIndex + 1];
                            ApplyTextStyleToParagraph(ann, textReq.AnnexAndBiblio);
                            ann.Format.HorizontalAlignment = HorizontalAlignment.Justify;
                            // Не продолжаем далеко — простая логика: только следующий параграф
                        }
                        continue;
                    }

                    // Ключевые слова: ищем "Ключевые слова" или "Ключевые слова:" и применяем стиль AnnexAndBiblio
                    if (plain.StartsWith("Ключевые слова", StringComparison.OrdinalIgnoreCase))
                    {

                        p.Format.HorizontalAlignment = HorizontalAlignment.Justify;
                        ApplyTextStyleToParagraph(p, textReq.AnnexAndBiblio);
                        continue;
                    }

                    // Библиография: если параграф является заголовком раздела "Библиография" или "Список литературы" — применяем стиль AnnexAndBiblio
                    if (plain.Equals("Библиография", StringComparison.OrdinalIgnoreCase) || plain.Equals("Список литературы", StringComparison.OrdinalIgnoreCase))
                    {
                        p.Format.HorizontalAlignment = HorizontalAlignment.Center;
                        continue;
                    }

                    // Авторы: часто идут сразу после заголовка; простая эвристика — параграф через 1-2 после заголовка и содержащий запятые
                    // Если параграф содержит несколько запятых и сокращения инициалов (например "И. И. Иванов"), применим Authors стиль
                    if (plain.Contains("И.") || plain.Contains("И. ") || plain.Split(',').Length > 1)
                    {
                        // Применяем осторожно: если параграф короткий — может быть список авторов
                        if (plain.Length < 200)
                        {
                            ApplyTextStyleToParagraph(p, textReq.Authors);
                            p.Format.HorizontalAlignment = HorizontalAlignment.Center;
                            continue;
                        }
                    }

                    // По умолчанию — основной текст
                    ApplyTextStyleToParagraph(p, textReq.Main);
                }
            }
        }

        static void ApplyTextStyleToParagraph(Paragraph p, TextStyleDto style)
        {
            if (style == null) return;

            // Character format для каждого TextRange внутри параграфа
            foreach (DocumentObject obj in p.ChildObjects)
            {
                if (obj is TextRange tr)
                {
                    if (!string.IsNullOrEmpty(style.Font)) tr.CharacterFormat.FontName = style.Font;
                    if (style.SizePt.HasValue) tr.CharacterFormat.FontSize = (float)style.SizePt.Value;
                    tr.CharacterFormat.Bold = style.Bold ?? tr.CharacterFormat.Bold;
                    tr.CharacterFormat.Italic = style.Italic ?? tr.CharacterFormat.Italic;
                }
            }

            // Paragraph format
            if (style.LineSpacing.HasValue)
            {
                // Spire: LineSpacing is in points; чтоб задать 1.5, можно использовать LineSpacingRule.Multiple и set LineSpacing*value
                try
                {
                    p.Format.LineSpacing = (float)(style.LineSpacing.Value * 12.0f); // приблизительная трансляция: 1.0->12pt, 1.5->18pt
                                                                                     // Также можно задать p.Format.LineSpacingRule = LineSpacingRule.Multiple;
                }
                catch { /* игнорируем при несоответствии API */ }
            }

            if (style.FirstLineIndentCm.HasValue)
            {
                p.Format.FirstLineIndent = (float)CmToPoints(style.FirstLineIndentCm.Value);
            }

            // Alignment
            if (!string.IsNullOrEmpty(style.Alignment))
            {
                p.Format.HorizontalAlignment = style.Alignment.ToLower() switch
                {
                    "left" => HorizontalAlignment.Left,
                    "center" => HorizontalAlignment.Center,
                    "right" => HorizontalAlignment.Right,
                    "justify" => HorizontalAlignment.Justify,
                    _ => p.Format.HorizontalAlignment
                };
            }
        }

        // ---------- Таблицы ----------
        static void ProcessTables(Document doc, TablesRulesDto tableReq)
        {
            int tableCounter = 0;

            // В Spire таблицы могут находиться как объекты Paragraph.ChildObjects или Section.ChildObjects

            foreach (Section sec in doc.Sections)
            {
                for (int i = 0; i < sec.Paragraphs.Count; i++)
                {
                    Paragraph p = sec.Paragraphs[i];

                    // Ищем таблицы среди дочерних объектов параграфа
                    for (int k = 0; k < p.ChildObjects.Count; k++)
                    {
                        var obj = p.ChildObjects[k];
                        if (obj is Table table)
                        {
                            tableCounter++;

                            // Выравнивание таблицы по центру
                            //try
                            //{
                            //     table.TableFormat.TableAlignment = TableRowAlignment.Center;
                            //}
                            // catch { /* если свойство недоступно - игнор */ }

                            // Применяем стиль ко всем ячейкам
                            foreach (TableRow row in table.Rows)
                            {
                                foreach (TableCell cell in row.Cells)
                                {
                                    // Убираем заливку, если нужно
                                    if (tableReq.PreventShading)
                                    {
                                        try { cell.CellFormat.BackColor = Color.Transparent; } catch { }
                                    }

                                    // Параграфы внутри ячейки
                                    foreach (Paragraph cp in cell.Paragraphs)
                                    {
                                        // текст в таблице: шрифт и размер
                                        foreach (DocumentObject inner in cp.ChildObjects)
                                        {
                                            if (inner is TextRange tr)
                                            {
                                                tr.CharacterFormat.FontName = "Times New Roman";
                                                tr.CharacterFormat.FontSize = tableReq.FontPt;
                                            }
                                        }

                                        // межстрочный — одинарный (попытка)
                                        try
                                        {
                                            cp.Format.LineSpacing = 12f; // примерно 1.0 x 12pt
                                        }
                                        catch { }
                                    }

                                    // Границы ячеек
                                    try
                                    {
                                        var borders = cell.CellFormat.Borders;
                                        // Цвет
                                        borders.Color = ColorTranslator.FromHtml(tableReq.TableBorder.ColorHex);
                                        // Толщина
                                        borders.LineWidth = (float)tableReq.TableBorder.WidthPt;
                                        // Стиль
                                        // Если API поддерживает BorderType:
                                        var bdTypeProp = borders.GetType().GetProperty("BorderType");
                                        if (bdTypeProp != null)
                                        {
                                            // Возможные значения: BorderStyle.Single/None/Dot/Dash — используем "Single"
                                            bdTypeProp.SetValue(borders, BorderStyle.Single);
                                        }
                                    }
                                    catch { /* игнорируем если API другой */ }
                                }
                            }

                            // Подпись таблицы: проверим есть ли подпись непосредственно перед таблицей (параграф выше)
                            // Требуется подпись формата: "Таблица N) - Название" выравненная по правому краю
                            // Если перед таблицей есть параграф, начинающийся с "Таблица" — оставим, иначе добавим пустую подпись над таблицей
                            bool hasCaptionAbove = false;
                            if (i - 1 >= 0)
                            {
                                var prev = sec.Paragraphs[i - 1];
                                if (!string.IsNullOrWhiteSpace(prev.Text) && prev.Text.TrimStart().StartsWith("Таблица", StringComparison.OrdinalIgnoreCase))
                                {
                                    hasCaptionAbove = true;
                                    // выравнивание подписи по центру над таблицей
                                    prev.Format.HorizontalAlignment = HorizontalAlignment.Center;
                                }
                            }
                            if (!hasCaptionAbove)
                            {
                                // создаём подпись над таблицей
                                Paragraph caption = sec.AddParagraph(); // добавим в конец секции — потом переместим под таблицу
                                caption.AppendText(tableReq.CaptionFormat.Replace("{n}", tableCounter.ToString()).Replace(" - {title}", "")); // название не извлекаем
                                caption.Format.HorizontalAlignment = HorizontalAlignment.Center;
                                // Переместим caption перед таблицей: удаление/вставка — простая реализация:
                                sec.Paragraphs.Remove(caption);
                                sec.Paragraphs.Insert(i, caption);
                                i++; // сдвигаем индекс, чтобы не зациклиться
                            }

                            // Подпись формата "Таблица N) - Название" должна быть выравнена по правому краю (по требованию)
                            if (i - 1 >= 0)
                            {
                                var cap = sec.Paragraphs[i - 1];
                                cap.Format.HorizontalAlignment = HorizontalAlignment.Right;
                                // Шрифт заголовка таблицы по центру таблицы над ней указан в требованиях, но пункт также требует подпись по правому краю -
                                // в примере мы помещаем над таблицей центр, а подпись правой — этот момент можно согласовать.
                            }
                        }
                    }
                }
            }
        }

        // ---------- Рисунки (фигуры) ----------
        static void ProcessFigures(Document doc, FiguresRulesDto figReq)
        {
            int figCounter = 0;
            foreach (Section sec in doc.Sections)
            {
                for (int i = 0; i < sec.Paragraphs.Count; i++)
                {
                    Paragraph p = sec.Paragraphs[i];
                    // Ищем DocPicture среди дочерних объектов параграфа
                    for (int k = 0; k < p.ChildObjects.Count; k++)
                    {
                        var obj = p.ChildObjects[k];
                        if (obj is DocPicture pic)
                        {
                            figCounter++;

                            // Выравниваем картинку по центру
                            try
                            {
                                pic.TextWrappingStyle = TextWrappingStyle.InFrontOfText; // пример
                                p.Format.HorizontalAlignment = HorizontalAlignment.Center;
                            }
                            catch { }

                            // Добавляем подпись под рисунком в формате "Рис. N. Название"

                            Paragraph caption = sec.AddParagraph();
                            caption.AppendText(figReq.CaptionFormat.Replace("{n}", figCounter.ToString()).Replace("{title}", "")); // название взять из соседних текстов, если есть
                                                                                                                                   // Формат подписи
                            foreach (DocumentObject inner in caption.ChildObjects)
                            {
                                if (inner is TextRange tr)
                                {
                                    tr.CharacterFormat.FontName = "Times New Roman";
                                    tr.CharacterFormat.FontSize = figReq.CaptionFontPt;
                                }
                            }
                            caption.Format.HorizontalAlignment = HorizontalAlignment.Center;

                            // Переместим подпись непосредственно после параграфа с картинкой
                            sec.Paragraphs.Remove(caption);
                            sec.Paragraphs.Insert(i + 1, caption);
                            i++; // пропустить подпись в дальнейшей итерации
                        }
                    }
                }
            }
        }

        // ---------- Библиография: минимальная проверка наличия секции ----------
        static void EnsureBibliographyHeader(Document doc, TextRulesDto textReq)
        {
            bool found = false;
            foreach (Section sec in doc.Sections)
            {
                foreach (Paragraph p in sec.Paragraphs)
                {
                    string t = (p.Text ?? "").Trim();
                    if (t.Equals("Библиография", StringComparison.OrdinalIgnoreCase) || t.Equals("Список литературы", StringComparison.OrdinalIgnoreCase))
                    {
                        found = true;
                        // Применим стиль библиографии (Times New Roman, 12pt)
                        ApplyTextStyleToParagraph(p, textReq.AnnexAndBiblio);
                    }
                }
            }

            if (!found)
            {
                // Добавим заголовок "Библиография" в конце документа
                Spire.Doc.Section lastSec = doc.Sections[doc.Sections.Count - 1];
                Paragraph p = lastSec.AddParagraph();
                p.AppendText("Библиография");
                ApplyTextStyleToParagraph(p, textReq.AnnexAndBiblio);
                p.Format.HorizontalAlignment = HorizontalAlignment.Center;
            }
        }

        // ---------- Копирайт (в конце документа после "Об авторах") ----------
        static void EnsureCopyrightBlock(Document doc, RequirementsDto req)
        {
            string copyrightTemplate = req.Copyright.Format; // "© {authors}, {year}"
            string year = DateTime.Now.Year.ToString();

            // Получим возможный список авторов из документа: простая эвристика — ищем параграфы, оформленные как Authors (курсив, центр)
            // В идеале список авторов берётся из заголовка/метаданных — если нет, можно запросить у пользователя.
            //string authorsList = ExtractAuthorsSimple(doc);
            //if (string.IsNullOrEmpty(authorsList))
           // {
                // если не нашли — добавим placeholder
           string     authorsList = "И. И. Иванов, И. И. Петров, Ю. С. Сидоров";
           // }

           string copyrightText = copyrightTemplate.Replace("{authors}", authorsList).Replace("{year}", year);

            // Проверим, есть ли уже такая строка в конце документа (после раздела "Об авторах")
            bool alreadyPresent = false;

            foreach (Spire.Doc.Section sec in doc.Sections.Cast<Spire.Doc.Section>().Reverse())
            {
                foreach (var item in sec.Paragraphs.Cast<object>().Reverse())
                {
                    var p = item as Paragraph;
                    if (p != null && (p.Text ?? "").Trim().StartsWith("©"))
                    {
                        alreadyPresent = true;
                        break;
                    }
                }
                if (alreadyPresent) break;
            }


            if (!alreadyPresent)
            {
                // Вставим в самый низ: после всех основных разделов на русском языке
                Section last = doc.Sections[doc.Sections.Count - 1];
                Paragraph p = last.AddParagraph();
                p.AppendText(copyrightText);
                // Формат: по центру или по левому краю? В требованиях говорится "в самом низу" — оставим по центру
                p.Format.HorizontalAlignment = HorizontalAlignment.Center;
                // Шрифт 12pt Times New Roman (как в bibliographic block)
                foreach (DocumentObject inner in p.ChildObjects)
                {
                    if (inner is TextRange tr)
                    {
                        tr.CharacterFormat.FontName = "Times New Roman";
                        tr.CharacterFormat.FontSize = 12f;
                    }
                }
            }
        }

        // Простейшая эвристика извлечения авторов
    }
}

                    

