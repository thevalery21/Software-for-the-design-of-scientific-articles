﻿using GigaChatAdapter;

//Укажите аутентификационные данные из личного кабинета
string authData = "MDE5OTkzZjYtNTAzNC03NGZmLThkNzAtZTZiNjRkOTUwMjBmOjJjY2NlY2E5LWIwYmUtNGQxOC1hNzUwLWYwMjkyNmQzMTE4Ng==";

//Запуск авторизации в гигачате
Authorization auth = new Authorization(authData, GigaChatAdapter.Auth.RateScope.GIGACHAT_API_PERS);
var authResult = await auth.SendRequest();

if (authResult.AuthorizationSuccess)
{
    Completion completion = new Completion();
    Console.WriteLine("Напишите запрос к модели. В ином случае закройте окно, если дальнейшую работу с чатботом необходимо прекратить.");

    while (true)
    {
        //Чтение промпта с консоли
        var prompt = Console.ReadLine();

        //Обновление токена, если он просрочился
        await auth.UpdateToken();

        //отправка промпта
        var result = await completion.SendRequest(auth.LastResponse.GigaChatAuthorizationResponse?.AccessToken, prompt);

        if (result.RequestSuccessed)
        {
            Console.WriteLine(result.GigaChatCompletionResponse.Choices.LastOrDefault().Message.Content);
        }
        else
        {
            Console.WriteLine(result.ErrorTextIfFailed);
        }
    }
}
else
{
    Console.WriteLine(authResult.ErrorTextIfFailed);
}
