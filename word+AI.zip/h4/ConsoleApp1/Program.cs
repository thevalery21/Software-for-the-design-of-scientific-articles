﻿using Spire.Doc;
using Spire.Doc.Documents;
using System.Drawing;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Создайте объект Document
            Document document = new();

            // Добавьте раздел
            Section section = document.AddSection();

            // Установите поля страницы
            section.PageSetup.Margins.All = 60f;

            // Добавьте заголовок
            Paragraph title_para = section.AddParagraph();
            title_para.AppendText("Это заголовок");
            title_para.ApplyStyle(BuiltinStyle.Title);

            // Добавьте подзаголовки
            Paragraph heading_one = section.AddParagraph();
            heading_one.AppendText("Это подзаголовок 1");
            heading_one.ApplyStyle(BuiltinStyle.Heading1);

            Paragraph heading_two = section.AddParagraph();
            heading_two.AppendText("Это подзаголовок 2");
            heading_two.ApplyStyle(BuiltinStyle.Heading2);

            Paragraph heading_three = section.AddParagraph();
            heading_three.AppendText("Это подзаголовок 3");
            heading_three.ApplyStyle(BuiltinStyle.Heading3);

            Paragraph heading_four = section.AddParagraph();
            heading_four.AppendText("Это подзаголовок 4");
            heading_four.ApplyStyle(BuiltinStyle.Heading4);

            // Добавьте абзац
            Paragraph normal_para = section.AddParagraph();
            normal_para.AppendText("Это абзац.");

            // Настройте стиль абзаца
            ParagraphStyle style = new ParagraphStyle(document);
            style.Name = "paraStyle";
            style.CharacterFormat.FontName = "Arial";
            style.CharacterFormat.FontSize = 13f;
            style.CharacterFormat.TextColor = Color.Brown;
            document.Styles.Add(style);

            // Примените стиль к абзацу
            normal_para.ApplyStyle("paraStyle");

            // Сохраните документ
            document.SaveToFile(@"C:\Users\admin\Downloads\CreateWordDocument.docx", FileFormat.Docx);
            

            // Освободите ресурсы
            document.Dispose();
        }
    }
}
