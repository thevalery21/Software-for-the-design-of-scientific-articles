
namespace WinFormsApp1V2
{
    public partial class Form1 : Form
    {
        private readonly GigaChatService _chatService;
        public Form1()
        {
            InitializeComponent();
            _chatService = new GigaChatService("MDE5OTkzZjYtNTAzNC03NGZmLThkNzAtZTZiNjRkOTUwMjBmOjJjY2NlY2E5LWIwYmUtNGQxOC1hNzUwLWYwMjkyNmQzMTE4Ng==");
        }
        private async void btnSend_Click(object sender, EventArgs e)
        {
            lblAnswer.Text = "Подождите...";
            bool isAuthorized = await _chatService.AuthorizeAsync();

            if (!isAuthorized)
            {
                lblAnswer.Text = "Авторизация провалилась.";
                return;
            }

            string userInput = txtPrompt.Text.Trim();
            if (string.IsNullOrEmpty(userInput))
            {
                lblAnswer.Text = "Вы ничего не ввели!";
                return;
            }

            try
            {
                string answer = await _chatService.SendMessageAsync(userInput);
                lblAnswer.Text = answer;
            }
            catch (Exception ex)
            {
                lblAnswer.Text = $"Ошибка: {ex.Message}";
            }
        }

    }
}
