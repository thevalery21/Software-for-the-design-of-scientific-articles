﻿using GigaChatAdapter;

namespace WinFormsApp1V2
{
    public class GigaChatService
    {
        private readonly string _authData;
        private Authorization _auth;

        public GigaChatService(string authData)
        {
            _authData = authData;
            _auth = new Authorization(_authData, GigaChatAdapter.Auth.RateScope.GIGACHAT_API_PERS);
        }

        public async Task<bool> AuthorizeAsync()
        {
            var authResult = await _auth.SendRequest();
            return authResult.AuthorizationSuccess;
        }

        public async Task<string> SendMessageAsync(string prompt)
        {
            await _auth.UpdateToken();
            Completion completion = new Completion();
            CompletionSettings settings = new CompletionSettings("GigaChat:latest", 0.1f, null, 2, 500);
            var result = await completion.SendRequest(_auth.LastResponse.GigaChatAuthorizationResponse.AccessToken, prompt, true, settings); //с сохранением истории

            if (result.RequestSuccessed && result.GigaChatCompletionResponse != null &&
    result.GigaChatCompletionResponse.Choices.Any())
            {
                return result.GigaChatCompletionResponse.Choices.First().Message.Content;
            }
            else
            {
                throw new Exception(result.ErrorTextIfFailed);
            }
        }
    }
}
