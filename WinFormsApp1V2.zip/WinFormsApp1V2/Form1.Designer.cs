﻿namespace WinFormsApp1V2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            txtPrompt = new TextBox();
            lblAnswer = new RichTextBox();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(449, 15);
            button1.Name = "button1";
            button1.Size = new Size(163, 78);
            button1.TabIndex = 0;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += btnSend_Click;
            // 
            // txtPrompt
            // 
            txtPrompt.Location = new Point(107, 44);
            txtPrompt.Name = "txtPrompt";
            txtPrompt.Size = new Size(283, 23);
            txtPrompt.TabIndex = 1;
            // 
            // lblAnswer
            // 
            lblAnswer.Location = new Point(33, 108);
            lblAnswer.Name = "lblAnswer";
            lblAnswer.Size = new Size(732, 315);
            lblAnswer.TabIndex = 2;
            lblAnswer.Text = "";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblAnswer);
            Controls.Add(txtPrompt);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TextBox txtPrompt;
        private RichTextBox lblAnswer;
    }
}
